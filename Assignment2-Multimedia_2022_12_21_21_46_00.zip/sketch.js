let circleSize=40;
//inserts image into canvas //
let image1=document.getElementById("cat");
image1.style.display="none";

let red=0;
let green=0;
let blue=0;
let sun=400;
let rect1= "green";
let rect2="gray";
function setup() {
  createCanvas(800, 600);
  // Get a random element from an array using the random(Array) syntax
let words = ['apple', 'bear', 'cat', 'dog'];
let word = random(words); // select random word
text(word, 10, 50); // draw the word
describe('word displayed at random. Either apple, bear, cat, or dog.');

}


 

function cat(){
  if (image1.style.display == "none"){
     image1.style.display ="block";
    
  } else {
    image1.style.display ="none";
  }
}

function draw() {
 
  
 
  ///creates sunrise on background//
  background(red+=5, green++, blue);
   //sun
  //outer
  noStroke();
  fill(255, 165, 0, 100);
  if(sun>144){
    circle(500, sun--, 200);
  }
  else if(sun==144){
    circle(500, sun, 220);
  }
  //inner
  noStroke();
  fill(255, 100, 0, 130);
  if(sun>144){
    circle(500, sun--, 150);
  }
  else if(sun==144){
    circle(500, sun, 150);
  }  

  
  ///// creates green rectangle(grass)//
  fill(rect1);
  rect(0,550,800,50);
  //////creates grey square (house)///
  fill(rect2);
  square(250,250,300);
  /////creates brown triangle(roof)///
  fill(102,51,0);
  triangle(250, 250, 400, 100, 550, 250);
  
  
  
  
  
  /////creates blue square (window)//
  fill(0, 0, 255);
  square(280,300,70);
  /////creates lime square(window)///
  
  fill(0, 255, 0);
  square(450,300,mouseX);
  ////creates red rectangle(door)///
  
  fill(255,0,0);
  strokeWeight(2);//creates an outline around shapes//
  stroke(51);
  rect(365,400,70,150);
  ////creates orange square(window)///
  fill(255,102,0);
  square(280,425,70);
  ////creates purple square(window)////
  fill(102,0,102);
  square(450,425,70); 
  
  /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(30,480,5,70);
  //////creates pink circle for flower///
  //flower head gets bigger when you move mouse up and down//
  fill(255,77,148);
  circle(30,460,mouseY);
   /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(70,480,5,70);
  //////creates light blue circle for flower///
  fill(0, 230, 230);
  circle(75,460,40);
   /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(115,480,5,70);
   //////creates purple circle for flower///
  fill(153,0,153);
  circle(120,460,40); 
   /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(750,480,5,70);
  //////creates pink circle for flower on the right side of canvas///
  fill(255,77,148);
  circle(750,460,40);
   /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(650,480,5,70);
  //////creates dark pink circle for flower on the right side of canvas///
  fill(255, 0, 85);
  circle(650,460,40);
   /////creates green rectangle for flower stem//
  fill(0,153,0);
  rect(700,480,5,70);
   //////creates purple circle for flower on the right side of canvas///
  fill(153,0,153);
  circle(700,460,40);
  

  
 
  
}





 function keyPressed(){
   //When A is pressed the grass changes to a lime green color//
   if(keyCode ==65)
     rect1 = "lime";
   //When D is pressed the house changes color//
   if (keyCode == 68)
     rect2 = "black;"
 }
 // it returns to original//
 function keyReleased(){
   if (key ==65){
     rect1="green;"
   }
   if (keyCode ==68){
     rect2="gray";
   }
 }
console.log('Counting numbers');
function addingUp(p1, p2, p3){
  return p1 + p2+ p3;
  
}
addingUp(1,2,3);
console.log(addingUp(1,2,3));
addingUp(1,2,3);
console.log(addingUp(1,2,3));


